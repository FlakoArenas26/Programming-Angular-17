﻿//static void Main(string[] args)
//{
//    Console.WriteLine("------------------------------------------------------------------------");
//    Console.WriteLine(" --------------  EVALUANDO LO APRENDIDO EN C#  ------------------- ");
//    Console.WriteLine("------------------------------------------------------------------------");

//    Console.WriteLine("1 --- Pepito");
//    Console.WriteLine("2 - prueba");

//    Console.WriteLine("Por favor ingrese el ejercicio que quiere visualizar");

//    string Option = Console.ReadLine().ToLower();
//    var Result = "";

//    switch (Option)
//    {
//        case "1":
//            Result = Exercise1.PuntoUno();
//            break;
//        case "2":
//            Result = Exercise1.PuntoUno();
//            break;
//        default:
//            break;
//    }

//    Console.WriteLine("El resultado es " + Result);

//    Console.WriteLine("Por favor ingrese el ejercicio que quiere visualizar");

//    string Optionq = Console.ReadLine().ToLower();
//}