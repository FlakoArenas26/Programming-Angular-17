﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoEnUno.Model.Model_Class
{
    class Exercise6
    {
        public static string PuntoSeis(string cadena)
        {
            int lenght = cadena.Length;
            return lenght.ToString();

        }
    }
   
}
